//
//  TagDetailViewController.swift
//  AddNewTag
//
//  Created by DJuser on 1/17/2560 BE.
//  Copyright © 2560 DJuser. All rights reserved.
//

import UIKit
import FirebaseDatabase
import IQKeyboardManagerSwift

class TagDetailViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {

    
    @IBOutlet weak var TagNamefield: UITextField!
    @IBOutlet weak var TagDescribeView: UITextView!
    @IBOutlet weak var myswitch: UISwitch!
    
    var mynotipickerview: UIPickerView!
    var notirange: [String]!
    
    var tagname: String = ""
    var tagdescribe: String = ""
    var notifytoggleval: Bool = false
    
    let ref = FIRDatabase.database().reference().child("TagsDetail")

    override func viewDidLoad() {
        super.viewDidLoad()
        mynotipickerview = UIPickerView()
        mynotipickerview.frame = CGRect(x: 0, y: 400, width: self.view.bounds.width, height: 200)
        
        mynotipickerview.showsSelectionIndicator = true
        
        mynotipickerview.delegate = self
        mynotipickerview.dataSource = self
        
        self.view.addSubview(mynotipickerview)
        notirange = ["Immediate", "Near", "Far"]

        
    }
    
    
    func OnOffTagNotification(for segue: UIStoryboardSegue, _ sender: Any?) {
        if myswitch.isOn {
        
        
        
        
        
        
        
        }
    }

    
    // total number of column(components)
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    // total number of rows
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return 3
    }
   
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return notirange[row]
    }
    
    
    @IBAction func Backdidtouch(_ sender: Any) {
        
        // switch view by setting navigation controller as root view controller
        // Create a main storyboard instance
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        // From main storyboard instantiate a view controller
        let ViewController = storyboard.instantiateViewController(withIdentifier: "AddNewTagViewController") as! ViewController
        
        // Get the app delegate
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        
        // Set Navigation Copntroller as root view controller
        appdelegate.window?.rootViewController = ViewController
        
    }
    

    @IBAction func Donedidtouch(_ sender: Any) {
        let tagdetailref = ref.childByAutoId()
        
        tagname = TagNamefield.text!
        tagdescribe = TagDescribeView.text!
       
        let tagdetailValue = [
            "TagName": tagname,
            "TagDescription": tagdescribe,
        ] as [String : Any]
        
        tagdetailref.setValue(tagdetailValue)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
