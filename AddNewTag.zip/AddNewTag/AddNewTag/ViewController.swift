//
//  ViewController.swift
//  AddNewTag
//
//  Created by DJuser on 1/15/2560 BE.
//  Copyright © 2560 DJuser. All rights reserved.
//

import UIKit
import FirebaseDatabase
import IQKeyboardManagerSwift

class ViewController: UIViewController {
    
    var uuid:String = ""
    var major:Int = 0
    var minor:Int = 0
    
    var dd:String = "11"
    
    @IBOutlet weak var uuidTextfield: UITextField!
    @IBOutlet weak var majorTextfield: UITextField!
    @IBOutlet weak var minorTextfield: UITextField!
    
    let rootref = FIRDatabase.database().reference().child("TagDetails")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func nextdidtouch(_ sender: Any) {
        let newtagconfig = rootref.childByAutoId()
        
        uuid = uuidTextfield.text!
        major = Int(majorTextfield.text!)!
        minor = Int(minorTextfield.text!)!
    
        let tagdetailValue = [
            "uuid": uuid,
            "major": major,
            "minor": minor,
    ] as [String : Any]
    
        newtagconfig.setValue(tagdetailValue)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

