//
//  ViewController.swift
//  location
//
//  Created by DJuser on 11/7/2559 BE.
//  Copyright © 2559 DJuser. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase

class ViewController: UIViewController, CLLocationManagerDelegate  {

    var rootref: FIRDatabaseReference!
    
    //let rootRef = FIRDatabase.database().reference()
    
    @IBOutlet weak var map: MKMapView!
    @IBOutlet weak var mylong: UITextField!
    @IBOutlet weak var mylat: UITextField!
    
    var manager:CLLocationManager!
    var myLocations: [CLLocation] = []
    
    var locManager: CLLocationManager!
    var currentLocation: CLLocation!
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
       
        rootref = FIRDatabase.database().reference()
        rootref.child("key").child("subkey").setValue("hello world")
        
        
        
        manager = CLLocationManager()
        manager.desiredAccuracy = kCLLocationAccuracyBest
        manager.requestAlwaysAuthorization()
        manager.startUpdatingLocation()
        
        locManager = CLLocationManager()
        locManager.requestWhenInUseAuthorization()
        currentLocation = CLLocation()
    
        if( CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedWhenInUse ||
            CLLocationManager.authorizationStatus() == CLAuthorizationStatus.authorizedAlways){
            currentLocation = locManager.location
        }
        
        mylong.text = "\(currentLocation.coordinate.longitude)"
        mylat.text = "\(currentLocation.coordinate.latitude)"
        
        //Setup our Map View
        map.showsUserLocation = true
 
    }
   
    
    func PushtoFirebase(latitude: String, longitude: String){
        let location = [
            "latitude": latitude,
            "longitude": longitude
        ]
        //rootref.childByAutoId().setValue(location)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

