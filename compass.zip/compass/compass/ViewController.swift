//
//  ViewController.swift
//  compass
//
//  Created by DJuser on 12/10/2559 BE.
//  Copyright © 2559 DJuser. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController ,CLLocationManagerDelegate {
    
    @IBOutlet weak var mytext: UITextField!
    @IBOutlet weak var myk: UITextField!
  
    var lm:CLLocationManager!
    var current: CLLocationDirection!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        lm = CLLocationManager()
        lm.delegate = self
        
        lm.startUpdatingHeading()
        lm.startUpdatingLocation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
       // mytext.text = "\(newHeading.magneticHeading)"
        //print(newHeading.magneticHeading)
        var h = newHeading.magneticHeading
        let k = newHeading.trueHeading
        
        if k >= 0 {
            h = k
        }
        
        let cards = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
        var dir = "N"
        
        for (ix, card) in cards.enumerated() {
            if h < 45.0/2.0 + 45.0*Double(ix) {
                dir = card
                break
            }
        }
        
        mytext.text = "degree: \(h) \(dir)"
    }
    
}
