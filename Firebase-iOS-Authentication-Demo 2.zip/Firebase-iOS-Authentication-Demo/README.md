# Firebase-iOS-Authentication-Demo
This is a iOS demo project for showing how Firebase iOS Auth works. (Swift 3)
