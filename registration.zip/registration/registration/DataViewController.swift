//
//  DataViewController.swift
//  registration
//
//  Created by macbook on 1/8/2560 BE.
//  Copyright © 2560 macbook. All rights reserved.
//

import UIKit
import Firebase

class DataViewController: UIViewController {

   
    
    @IBOutlet weak var usernamelabel: UILabel!
    @IBOutlet weak var emailfield: UITextField!
    @IBOutlet weak var passwordfield: UITextField!
    @IBOutlet weak var logoutbutton: UIButton!
   
   
   
    
    @IBOutlet weak var dataLabel: UILabel!
    var dataObject: String = ""


    override func viewDidLoad() {
        super.viewDidLoad()
            if let user = FIRAuth.auth()?.currentUser
            {
                self.logoutbutton.alpha = 1.0
                self.usernamelabel.text = user.email
            }
            else
            {
                self.logoutbutton.alpha = 0.0
                self.usernamelabel.text = ""

            }
    }

    @IBAction func signupaction(_ sender: Any) {
        if self.emailfield.text == "" || self.passwordfield.text == ""
        {
            let alertController = UIAlertController(title: "oops", message: "please enter email and password.", preferredStyle: .alert)
            let defaultaction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultaction)
            self.present(alertController, animated: true, completion: nil)
        }
        
        else
        {
            FIRAuth.auth()?.createUser(withEmail: self.emailfield.text!, password: self.passwordfield.text!, completion: {(user, error) in
                
                if error == nil
                {
                    self.logoutbutton.alpha = 1.0
                    self.usernamelabel.text = user?.email
                    self.emailfield.text = ""
                    self.passwordfield.text = ""
                    
                }
                else
                {
                    let alertController = UIAlertController(title: "oops", message: error?.localizedDescription , preferredStyle: .alert)
                    let defaultaction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultaction)
                    self.present(alertController, animated: true, completion: nil)

                }
            })
        }
        
    }
    
    
    @IBAction func loginaction(_ sender: Any) {
        
        if self.emailfield.text == "" || self.passwordfield.text == ""
        {
            let alertController = UIAlertController(title: "oops", message: "please enter email and password.", preferredStyle: .alert)
            let defaultaction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultaction)
            self.present(alertController, animated: true, completion: nil)
        }
        else
        {
            FIRAuth.auth()?.signIn(withEmail: self.emailfield.text!, password: self.passwordfield.text!, completion: {(user, error) in
                if error == nil
                {
                    self.logoutbutton.alpha = 1.0
                    self.usernamelabel.text = user?.email
                    self.emailfield.text = ""
                    self.passwordfield.text = ""
                    
                }
                else
                {
                    let alertController = UIAlertController(title: "oops", message: error?.localizedDescription , preferredStyle: .alert)
                    let defaultaction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultaction)
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            })
        }
    }
    
    
    @IBAction func logoutaction(_ sender: Any) {
        try!FIRAuth.auth()?.signOut()
        self.usernamelabel.text = ""
        self.logoutbutton.alpha = 0.0
        self.emailfield.text = ""
        self.passwordfield.text = ""
    }

    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.dataLabel!.text = dataObject
    }

    
    
    
   }

