//
//  ViewController.m
//  findme
//
//  Created by iMac on 10/6/2559 BE.
//  Copyright (c) 2559 appLunix. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{

    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // Create a NSUUID object
   // NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:@"D5E5025C-1261-472B-A57A-62D1A38227BB"];
    //NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:@"7C278BDA-B644-4520-8F0C-720EAF059935"];
    //NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:@"2729ABCD-0102-0304-5C6D-7E8F00000001"];
    NSUUID *uuid = [[NSUUID alloc] initWithUUIDString:@"74278bda-b644-4520-8f0c-720eaf059935"];

  
    // Initialize the Beacon Region
    self.myBeaconRegion = [[CLBeaconRegion alloc] initWithProximityUUID:uuid
        major:42
        minor:42
        identifier:@"MyiBeacon"
        //identifier:@"Radioland iBeacon"

    ];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)ButtonClicked:(id)sender {
    
    // Get the beacon data to advertise
    self.myBeaconData = [self.myBeaconRegion peripheralDataWithMeasuredPower:nil];
    
    // Start the peripheral manager
    self.peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self
        queue:nil
        options:nil];
}

-(void)peripheralManagerDidUpdateState:(CBPeripheralManager*)peripheral
{
    if (peripheral.state == CBPeripheralManagerStatePoweredOn)
    {
        // Bluetooth is on
        
        // Update our status label
        self.StatusLabel.text = @"Broadcasting...";
        
        // Start broadcasting
        [self.peripheralManager startAdvertising:self.myBeaconData];
    }
    else if (peripheral.state == CBPeripheralManagerStatePoweredOff)
    {
        // Update our status label
        self.StatusLabel.text = @"Stopped";
        
        // Bluetooth isn't on. Stop broadcasting
        [self.peripheralManager stopAdvertising];
    }
    else if (peripheral.state == CBPeripheralManagerStateUnsupported)
    {
        self.StatusLabel.text = @"Unsupported";
    }

}
@end
