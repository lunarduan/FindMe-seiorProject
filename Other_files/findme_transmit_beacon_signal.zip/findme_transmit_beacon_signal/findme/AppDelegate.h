//
//  AppDelegate.h
//  findme
//
//  Created by iMac on 10/6/2559 BE.
//  Copyright (c) 2559 appLunix. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
