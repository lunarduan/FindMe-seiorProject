//
//  AppDelegate.h
//  ipad_transmit
//
//  Created by DJuser on 10/20/2559 BE.
//  Copyright © 2559 DJuser. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

