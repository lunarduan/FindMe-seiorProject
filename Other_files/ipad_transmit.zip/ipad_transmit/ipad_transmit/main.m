//
//  main.m
//  ipad_transmit
//
//  Created by DJuser on 10/20/2559 BE.
//  Copyright © 2559 DJuser. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
